#'============================================================================
#' Enviromics em Melhoramento de Plantas - 2022 - GenMelhor
#'============================================================================
#'
#' Script n04: O que fazer com os dados ambientais?
#'           : Modulo 2: Caracterizacao ambiental - continuacao
#' 
#' Autor     : Germano Costa Neto
#' Data      : 06-04-2022
#' Atualizado:
#' 
#' Precisa de ajuda? fale no forum publico:
#' https://groups.google.com/u/1/g/envrtype?pli=1
#' 
#'============================================================================


## Soil Grids - continuacao
#'============================================================================

env.i = c("1_AN","1_PI","2_AN","2_PI") # environment ID
lat = c(-22.875,-22.705,-22.875,-22.705) # latitude coordinates
lon = c(-47.997,-47.637,-47.997,-47.637) # longitude coordinates
plant.date = c("2016-01-26","2016-01-21","2017-01-12","2017-01-10") # year-month-day
harv.date = c('2016-08-01',"2016-07-14","2017-07-25","2017-07-15")

df.clim = get_weather(env.id = env.i,lat = lat,lon = lon,start.day = plant.date,end.day = harv.date)


# faca download: https://github.com/allogamous/EnvRtype/blob/master/SoilGrid.zip
home.dir = getwd()  # diretorio home
dir = paste0(home.dir,'/SoilGrid') # crie uma 
unzip(zipfile = 'SoilGrid.zip')

(soil_grid = list.files(path = dir,pattern = 'tif'))
(soil_name = gsub(soil_grid,pattern = '.tif',replacement = ''))

require(raster)
env.data = data.frame(env = env.i,LAT = lat, LON = lon)
soil_data = c()
for(i in 1:length(soil_grid)) soil_data = rbind(soil_data,data.frame(Feature = soil_name[i],extract_GIS(covraster = raster(paste0(dir,'/',soil_grid[i])),name.out = 'Soil_Grid',env.data = env.data)))

head(soil_data)

soil_data <- soil_data %>% dcast(env+LAT+LON~Feature,value.var = 'Soil_Grid')


# Montando diversos modelos!
#'============================================================================

################ BOX 12: Basic usage of get_kernel function ################
data("maizeYield") # toy set of phenotype data (grain yield per environment)
data("maizeG"    ) # toy set of genomic relationship for additive effects 
data("maizeWTH")   # toy set of environmental data

# exemplo: usando algumas variaveis especificas a media destas no ciclo

ECs  = W_matrix(env.data = maizeWTH, 
                var.id = c("FRUE",'PETP','SRAD',"T2M_MAX"),
                statistic = 'mean')
## KG and KE might be a list of kernels

KE = list(W = env_kernel(env.data = ECs,gaussian = F)[[2]])
KG = list(G=maizeG);

D_matrix
A_matrix


## Creating kernel models with get_kernel
MM    = get_kernel(K_G = KG, y = y,gid = gid,env = env, data = maizeYield,model = "MM") 
MDs   = get_kernel(K_G = KG, y = y,gid = gid,env = env,  data = maizeYield, model = "MDs") 

dim(maizeG)
str(maizeYield)
levels(maizeYield$gid)



EMM   = get_kernel(K_G = KG, K_E = KE, y = y,gid = gid,env = env,  data = maizeYield, model = "EMM")

# porque??? que erro eh esse?
maizeYield <- droplevels(maizeYield)

MM    = get_kernel(K_G = KG, y = y,gid = gid,env = env, data = maizeYield,model = "MM") 
MDs   = get_kernel(K_G = KG, y = y,gid = gid,env = env,  data = maizeYield, model = "MDs") 
EMM   = get_kernel(K_G = KG, K_E = KE, y = y,gid = gid,env = env,  data = maizeYield, model = "EMM")
EMDs  = get_kernel(K_G = KG, K_E = KE, y = y,gid = gid,env = env,  data = maizeYield, model = "EMDs") 
RMMM  = get_kernel(K_G = KG, K_E = KE, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMM") 
RNMDs = get_kernel(K_G = KG, K_E = KE, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMDs") 



################ BOX 13: Basic usage of kernel_model ################
fixed = model.matrix(~0+env, maizeYield)

y   = "value"      # name of the vector of phenotypes
gid = "gid"        # name of the vector of genotypes
env = "env"        # name of the vector of environments


fit   = kernel_model(y = y,env = env,gid = gid, data = maizeYield,random = RMMM )

fit$yHat    # predicted phenotype values
fit$VarComp # variance components and confidence intervals

cor(fit$yHat,maizeYield$value)

fit$BGGE    # full output of Hierarchical Bayesian Modeling
