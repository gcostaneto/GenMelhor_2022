#'============================================================================
#' Enviromics em Melhoramento de Plantas - 2022 - GenMelhor
#'============================================================================
#'
#' Script n05: Data analytics and predictive research
#'           : Modulo 3: Modelos preditivos e associacoes fenotipo-ambiente
#' 
#' Autor     : Germano Costa Neto
#' Data      : 06-04-2022
#' Atualizado:
#' 
#' Precisa de ajuda? fale no forum publico:
#' https://groups.google.com/u/1/g/envrtype?pli=1
#' 
#'============================================================================

# exemplos do pacote EnvRtype ####
#'============================================================================
data("maizeYield") # toy set of phenotype data (grain yield per environment)
data("maizeG"    ) # toy set of genomic relationship for additive effects 
data("maizeWTH")   # toy set of environmental data
y   = "value"      # name of the vector of phenotypes
gid = "gid"        # name of the vector of genotypes
env = "env"        # name of the vector of environments



# Passo 1: processando os dados ambientais para a matrix W  ####
#'============================================================================
#'
### 1- Environmental Covariables (ECs)
stages    = c('VE','V1_V6','V6_VT','VT_R1','R1_R3','R3_R6',"H")
interval  = c(0,7,30,65,70,84,105)

EC1  = W_matrix(env.data = maizeWTH, var.id = 'FRUE')
EC2  = W_matrix(env.data = maizeWTH, var.id = 'PETP')
EC3  = W_matrix(env.data = maizeWTH, var.id = c('FRUE','PETP'))
EC4  = W_matrix(env.data = maizeWTH, var.id = 'FRUE',
                by.interval = T,time.window = interval,names.window = stages)
EC5  = W_matrix(env.data = maizeWTH, var.id = 'PETP',
                by.interval = T,time.window = interval,names.window = stages)
EC6  = W_matrix(env.data = maizeWTH, var.id = c('FRUE','PETP'),
                by.interval = T,time.window = interval,names.window = stages)

# Passo 2: organizando nossas estruturas de relacionamento ambiental   ####
#'============================================================================
#'
### 2- Kernels
K1 = list(FRUE = env_kernel(env.data = EC1)[[2]])
K2 = list(PETP = env_kernel(env.data = EC2)[[2]])
K3 = list(FRUE_PETP = env_kernel(env.data = EC3)[[2]])
K4 = list(FRUE = env_kernel(env.data = EC4)[[2]])
K5 = list(PETP = env_kernel(env.data = EC5)[[2]])
K6 = list(FRUE_PETP = env_kernel(env.data = EC6)[[2]])


# Passo 3: organizando as estruturas em kernels para rodar nas futuras funcoes  ####
#'============================================================================

### 3- Obtain Kernel Models
M0  = get_kernel(K_G = KG,  y = y,gid = gid,env = env,  data = maizeYield, model = "MDs") 
M1  = get_kernel(K_G = KG, K_E = K1, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMDs") 
M2  = get_kernel(K_G = KG, K_E = K2, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMDs") 
M3  = get_kernel(K_G = KG, K_E = K3, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMDs") 
M4  = get_kernel(K_G = KG, K_E = K4, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMDs") 
M5  = get_kernel(K_G = KG, K_E = K5, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMDs") 
M6  = get_kernel(K_G = KG, K_E = K6, y = y,gid = gid,env = env,  data = maizeYield, model = "RNMDs") 

## plot for each EC (e.g., EC1, EC2, EC3...)
superheat(env_kernel(env.data = EC1)[[2]],
          pretty.order.rows = TRUE,
          pretty.order.cols = TRUE,
          row.dendrogram = F,
          col.dendrogram = F,
          grid.vline.col = "white",
          grid.hline.col = "white",
          #row.dendrogram = T,
          legend.width = 4,
          left.label.size = 0.1,
          bottom.label.text.size = 5,
          bottom.label.size = 0.2,
          bottom.label.text.angle = 90,
          heat.pal = viridis::inferno(100),
          #  heat.pal = viridis::magma(100),
          legend.text.size = 17,
          #   X.text = round(as.matrix(a),1),X.text.col="white",
          legend.height=0.2)

# Passo 4: parametros para rodar o modelo hierarquico bayesiano
#'============================================================================

################  BOX 17: Fitting Genomic-enabled models with enviromic data ################ 
fixed = model.matrix(~0+env,maizeWTH)

iter = 1000
burn = 500
seed = 78172
thin = 10


model = paste0('M',0:6)
Models = list(M0,M1,M2,M3,M4,M5,M6)

# Vamos rodar cada modelo em um "loop" simples e estudar os componentes de variancia
#'============================================================================
Vcomp <- c()
for(MODEL in 1:length(Models)){
  set.seed(seed)
  fit <- kernel_model(data = maizeYield,y = y,env = env,gid = gid,
                      random = Models[[MODEL]],#fixed = Z_E,
                      iterations = iter,burnin = burn,thining = thin)
  
  Vcomp <- rbind(Vcomp,data.frame(fit$VarComp,Model=model[MODEL]))
}

Vcomp

reshape2::dcast(Vcomp,Model~Type,sum,value.var = 'Var')
reshape2::dcast(Vcomp,Model~Type,sum,value.var = 'CI_lower')
reshape2::dcast(Vcomp,Model~Type,sum,value.var = 'CI_upper')


## QUESTOES:
#'============================================================================
# se mudar os parametros bayesianos, muda os componentes? mais iteracoes? burnin diferente?
# preciso ou nao usar efeito fixo?
# os kernels precisam todos ter a mesma dimensao?



#'============================================================================
#' Estudo N2 : kernels por estagio de desenvolvimento
#'============================================================================

################  BOX 18: Bulding enviromic kernels for each development stage ################ 
data("maizeYield") # toy set of phenotype data (grain yield per environment)
data("maizeG"    ) # toy set of genomic relationship for additive effects 
data("maizeWTH")   # toy set of environmental data
y   = "value"      # name of the vector of phenotypes
gid = "gid"        # name of the vector of genotypes
env = "env"        # name of the vector of environments

## Organizing Environmental Covariables (ECs) in W matrix
stages    = c('VE','V1_V6','V6_VT','VT_R1','R1_R3','R3_R6',"H")
interval = c(0,7,30,65,70,84,105)
id.vars  = names(maizeWTH)[c(10:15,23,25:30)]

W.matrix = W_matrix(env.data = maizeWTH,env.id = 'env',
                    var.id = id.vars,by.interval = T,time.window = interval,
                    names.window = stages,center = F,scale = F )


## Kernel for the involving all development stages
K_F <- env_kernel(env.data = W.matrix,gaussian = T)[[2]]
## Kernels for each development stage
K_S <- env_kernel(env.data = W.matrix,gaussian = T,stages = stages[2:5])[[2]]
# K_G (genotype) and K_E (environment) must be a list of kernels
# So:
K_G = list(G = maizeG)
# And:
K_F <- list(E = K_F)

# for K_S, we dont need to create a list because K_S is already a list of kernels for each development stage
## Assembly Genomic and Enviromic Kernel Models


M1 = get_kernel(K_G = K_G,data = maizeYield,env = env,gid = gid,y = y, model = "MDs") # baseline model
M2 = get_kernel(K_G = K_G, K_E = K_F, data = maizeYield,env = env,gid = gid,
                y = y, model = "RNMM",dimension_KE = 'q') # reaction-norm 1
M3 = get_kernel(K_G = K_G, K_E = K_S, data = maizeYield,env = env,gid = gid,
                y = y,model = "RNMM",dimension_KE = 'q') # reaction-norm 2

model = c('Baseline Genomic','Reaction-Norm','Reaction-Norm for each Dev.Stage')
Models = list(M1,M2,M3) # for running all models in loop

iter = 10E3 # number of iterations
burn = 5E3  # number of burn in
thin = 10   # number for thining

Z_E = model.matrix(~0+env,data=maizeYield) # fixed environmental effects

Vcomp <- c()
for(MODEL in 1:length(Models)){
  set.seed(seed)
  fit <- kernel_model(data = maizeYield,y = y,env = env,gid = gid,
                      random = Models[[MODEL]],fixed = Z_E,
                      iterations = iter,burnin = burn,thining = thin)
  
  Vcomp <- rbind(Vcomp,data.frame(fit$VarComp,Model=model[MODEL]))
}

Vcomp



## plots for each kernel per stage (list K_S object)
superheat(K_S$R1_R3,
          pretty.order.rows = TRUE,
          pretty.order.cols = TRUE,
          row.dendrogram = F,
          col.dendrogram = F,
          grid.vline.col = "white",
          grid.hline.col = "white",
          #row.dendrogram = T,
          legend.width = 4,
          left.label.size = 0.1,
          bottom.label.text.size = 5,
          bottom.label.size = 0.2,
          bottom.label.text.angle = 90,
          heat.pal = viridis::inferno(100),
          #  heat.pal = viridis::magma(100),
          legend.text.size = 17,
          #   X.text = round(as.matrix(a),1),X.text.col="white",
          legend.height=0.2)


#'============================================================================
#'Estudo N3: Alguns esquemas de validacao cruzada e predicao "computacionalmente efficiente"
#'============================================================================
#'
################  BOX 19: Genomic Prediction using kernel_model ################ 
## Cross-validation to assess predictive ability of GP models (kernel_model function)
source('https://raw.githubusercontent.com/gcostaneto/SelectivePhenotyping/master/cvrandom.R')




iter = 5E3
burn = 1E3
thin = 10

## CV1: removo alguns genotipos de TODOS os ambientes
rep  = 3
seed = 1010
f    = 0.20
TS = Sampling.CV1(gids = maizeYield$gid,f = f,seed = seed,rep = rep,gidlevel = F)

# QUESTAO: qual hipotese eu estou testando em CV1?


require(foreach)
require(EnvRtype)


#'============================================================================
#' Rodando em paralelo
#'============================================================================

Y = maizeYield 

results <-
  foreach(REP = 1:rep, .combine = "rbind")%:% 
  foreach(MODEL = 1:length(model), .combine = "rbind")%dopar% {
    
    
    yNA      <- Y
    tr       <- TS[[REP]]
    yNA$value[-tr] <- NA
    
    Z_E = model.matrix(~0+env,data=yNA) # fixed environmental effects
    
    fit <- kernel_model(data = yNA,y = y,env = env,gid = gid,
                        random = Models[[MODEL]],fixed = Z_E,
                        iterations = iter,burnin = burn,thining = thin)
    
    
    df<-data.frame(Model = model[MODEL],rep=REP,
                   rTr=cor(Y$value[tr ], fit$yHat[tr ],use = 'complete.obs'),
                   rTs=cor(Y$value[-tr], fit$yHat[-tr],use = 'complete.obs'))
    
  #  write.table(x = df,file = 'point-estimate_r.txt',sep=',',append = T,row.names=T)
    
    output <- data.frame(obs=Y$value,pred=fit$yHat,
                         gid=Y$gid, env=Y$env,
                         Model = model[MODEL],rep=REP,pop=NA)
    
    
    output$pop[tr ] <- 'training'
    output$pop[-tr] <- 'testing'
    
    return(output)
  }
#stopCluster(cl)



results
require(plyr)
pa = ddply(results,.(rep,pop,Model),summarise,r = cor(obs,pred))
ddply(pa,.(pop,Model),summarise, pa = round(mean(r),3),sd = round(sd(r),3))

# QUESTAO: salvar apenas a capacidade preditiva ou todos os dados?




## CV00: removendo genotipos E ambientes

# vamos remover 2 ambientes aleatorios da nossa rede
rep  = 3
seed = 8172
f    = 0.20
remover_ambiente = 2
TS=Sampling.CV0(gids = Y$gid,envs = Y$env,out.env = remover_ambiente ,f = f,seed = seed,rep = rep)



#
cl <- makeCluster(3)
registerDoParallel(cl)

results <-foreach(REP = 1:rep, .combine = "rbind")%:%
  foreach(MODEL = 1:length(model), .combine = "rbind")%dopar% {
    
    
    yNA      <- Y
    tr       <- TS[[REP]]$training
    yNA$value[-tr] <- NA
    
    Z_E = model.matrix(~0+env,data=Y)
    fit <- kernel_model(data = yNA,y = y,env = env,gid = gid,
                        random = Models[[MODEL]],fixed = Z_E,
                        iterations = iter,burnin = burn,thining = thin)
    
    
    output <- data.frame(obs=Y$value,pred=fit$yHat,
                         gid=Y$gid, env=Y$env,
                         Model = model[MODEL],rep=REP,pop=NA)
    
    
    output$pop[tr ] <- 'training'
    output$pop[-tr] <- 'testing'
    
    return(output)
  }

stopCluster(cl)

pa = ddply(results,.(rep,pop,Model),summarise,r = cor(obs,pred))
ddply(pa,.(pop,Model),summarise, pa = round(mean(r),3),sd = round(sd(r),3))

# QUESTOES:
# O que o CV0 nos conta?

# Quais outros esquemas podemos fazer? Pra que?


# PLOS: usando PLS
#'============================================================================
#'
require(plsdepot)
