#'============================================================================
#' Enviromics em Melhoramento de Plantas - 2022 - GenMelhor
#'============================================================================
#'
#' Script n03: O que fazer com os dados ambientais?
#'           : Modulo 2/3: Caracterizao ambiental e Kernels de relacionamento
#' 
#' Autor     : Germano Costa Neto
#' Data      : 06-04-2022
#' Atualizado:
#' 
#' Precisa de ajuda? fale no forum publico:
#' https://groups.google.com/u/1/g/envrtype?pli=1
#' 
#'============================================================================

# pacotes necessarios

require(AGHmatrix) # instalem
require(plyr)
require(reshape2)
require(ggplot2)


# env_typing (ou T-matrix, se usado na predicao) - continuacao
#'============================================================================


env.data = get_weather(env.id = 'LOSBANOS',#country = 'PHL',
                       lat = 14.170,lon = 121.241,variables.names = 'T2M',
                       start.day = '2000-03-01',end.day = '2020-03-01')

card = list(T2M=c(0,8,15,28,40,45,Inf)) # a list of vectors containing empirical and cardinal thresholds
env_typing(env.data = env.data,env.id = 'env', var.id = 'T2M', cardinals = card)


data("maizeWTH")   # toy set of environmental data
card = list(T2M=c(0,8,15,28,40,45,Inf)) # a list of vectors containing empirical and cardinal thresholds
env_typing(env.data = maizeWTH,env.id = 'env', var.id = 'T2M', cardinals = card)


# vamos tentar outra variavel
#'============================================================================

card = list(PRECTOT = c(0,5,10,25,50,75,90), T2MDEW = NULL) # cardinals and data-driven limits
env_typing(env.data = env.data,env.id = 'env', var.id = var, cardinals = card)

data("maizeWTH")   # toy set of environmental data
card = list(T2M=c(0,8,15,28,40,45,Inf)) # a list of vectors containing empirical and cardinal thresholds
env_typing(env.data = maizeWTH,env.id = 'env', var.id = var, cardinals = card)

# Download dos dados climaticos
#'============================================================================

lat = c(-22.875,-22.705,-22.875,-22.705) # latitude coordinates
lon = c(-47.997,-47.637,-47.997,-47.637) # longitude coordinates
env = c("E1","E2","E3","E4") # environmental ID
plant.date = c("2016-01-26","2016-01-21","2017-01-12","2017-01-10")
harv.date = c('2016-08-01',"2016-07-14","2017-07-25","2017-07-15")


df.clim <- get_weather(env.id = env,lat = lat,lon = lon,start.day = plant.date,end.day = harv.date) 
head(df.clim) # data set of weather data

# jeito "rapido" de processar (mas hoje em dia nao recomendo mais!)
# usem os param_temperature(), param_radiaton() e param_atmospheric()
#'============================================================================

df.clim <- processWTH(env.data = df.clim,Tbase1 = 8,Tbase2 = 45,Topt1 = 30,Topt2 = 37) # 
head(df.clim)


# paineis de covariaveis ambientais: quantitativas (W) e qualitativas t(tipos, T )
#'============================================================================

source('https://raw.githubusercontent.com/allogamous/EnvRtype/master/R/plot_panel.R')

(var.i = names(df.clim)[c(9:17,19:28)])

ET = env_typing(env.data = df.clim,env.id = 'env',var.id = var.i,format = 'wide')

plot_panel(ET,title = 'Panel of Environmental Types')


EC = W_matrix(env.data = df.clim,env.id = 'env',var.id = var.i,statistic = 'mean')

plot_panel(EC,title = 'Panel of Environmental Covariables')



# Matrix W de covariaveis ambientais (Jarquin et al., 2014; modificada por Morais-Junior et al. 2018)
#'============================================================================

id.var <- names(df.clim)[c(9:17,19:28)] # names of the variables

# janelas temporais: 0, 14, 35, 65, 90, 120 dias
# quando colocamos "by.interval" estamos dizendo que as funcoes devem rodar estatisticas por intervalo de tempo
W <- W_matrix(env.data = df.clim,var.id = id.var,
             statistic = 'quantile',
             by.interval = TRUE,
             time.window = c(0,14,35,65,90,120)) # em dias!


dim(W) # 342 covariaveis!
W <- as.matrix(W)

load('Molecular_USP.RData') # no repositorio do gcostaneto/KernelMethods

M <- usp$M # matriz de marcadores
dim(M)  # 570 genotipos por 34 mil marcadores


# dados fenotipicos
#'============================================================================

pheno_MET <- readRDS('Fenotipos_MET_milho')
head(pheno_MET)


source('https://raw.githubusercontent.com/gcostaneto/KernelMethods/master/Dominance_Matrix.R') # codes for dominance effects


# relacionamento genetico por meio de efeitos aditivos
source('https://raw.githubusercontent.com/gcostaneto/KernelMethods/master/GBLUP_Kernel.R') # codes for GB kernel
K_A <- GB_Kernel(X = M,is.center = FALSE)  # Genomic relationship for additive effects
dim(K_A)


# Recomendacao:
# pacote AGHmatrix (Brazil zil zil,by Rodrigo Amadeu, Ivone, Leticia, Ferrao, prof Augusto, Prof Marcio)

require(AGHmatrix)
K_D <- Gmatrix(SNPmatrix = M,method = 'Vitezica',ploidy = 2)
K_A <- Gmatrix(SNPmatrix = M,method = 'VanRaden',ploidy = 2)

# por que sera que nao roda? Valores Na? por conta dos conceitos geneticos?
K_W <- Gmatrix(SNPmatrix = W,method = 'VanRaden',ploidy = 2)


# vamos tentar usando o pacote EnvRtype 

K_W <- env_kernel(env.data = W,gaussian = F) # kernel linear, analogo a Gmatrix

# questao: porque apareceu NaN ??

apply(W,1,var) # existem NAs!

colnames(W)[is.na(apply(W,2,var))] # existem NAs!

W_matrix <- W[,!is.na(apply(W,2,var))]

# porque ainda nao roda??? por conta dos conceitos geneticos?
K_W <- Gmatrix(SNPmatrix = W_matrix,method = 'VanRaden',ploidy = 2)

# vamos tentar usando o pacote EnvRtype 
K_W <- env_kernel(env.data = W_matrix,gaussian = F) # kernel linear, analogo a Gmatrix


K_W <- env_kernel(env.data = W_matrix,gaussian = T) # kernel nao-linear, Gaussian Kernel


## e se eu quiser um gaussian kernel para efeitos "geneticos"?

# atencao: funcao demorada!
source('https://raw.githubusercontent.com/gcostaneto/KernelMethods/master/Gaussian_Kernel.R') # codes for GK kernel
K_G   <- GK_Kernel(X = list(A=M)) # vc pode montar varios kernels ao mesmo tempo por meio da lista...
dim(K_G$A)


### Deep Kernel

source('https://raw.githubusercontent.com/gcostaneto/KernelMethods/master/DeepKernels.R')

# basic Ark-cosine kernels (1)
K_A  <- get_GC1(M = list(A=M)) # K_A 1
dim(K_A$A)

K_W  <- get_GC1(M = list(W=W_matrix)) # K_E 1

# Montando os modelos de predicao no pacote EnvRtype
#'============================================================================
# get_kernel() = ajusta os kernels pra n x n dimensiion
# kernel_model() = roda os modelos de kernel usando processos bayesianos

# GBLUP (exemplo)
K_A <- Gmatrix(SNPmatrix = M,method = 'VanRaden',ploidy = 2)


K_A <- list(A=K_A) # sempre em listas pois isso permite colocar varios "kernels geneticos"


# GBLUP sem dado ambiental e sem interacao GxE (MM)
M1 <-get_kernel(K_G = K_A,K_E = NULL, env = 'env',gid='gid',y='value',data = pheno_MET,model = 'MM')

# GBLUP sem dado ambiental e COM interacao GxE (MDs)
M2 <-get_kernel(K_G = K_A,K_E = NULL, env = 'env',gid='gid',y='value',data = pheno_MET,model = 'MDs')

# e como seria com dados ambientais????


